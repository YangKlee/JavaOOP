/*
	Author: YangKlee - Nguyen Khanh Duong
	Date: 4 thg 1, 2025
*/ 
package references;
import model.*;
import java.util.ArrayList;
import java.util.Vector;

public interface data {
	public static ArrayList<candidate> listCandidate = new ArrayList<candidate>();
	public static ArrayList<dataError> listError = new ArrayList<dataError>();
}
