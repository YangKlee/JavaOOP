/*
	Author: YangKlee - Nguyen Khanh Duong
	Date: 8 thg 1, 2025
*/ 
package DAO;

public interface DAOInterface <T> {
	public boolean insertDB(T t);
	
	
}
