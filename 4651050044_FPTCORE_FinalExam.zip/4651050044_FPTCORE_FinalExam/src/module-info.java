/**
 * 
 */
/**
 * 
 */
module FPT_FinalExam_template {
	requires java.desktop;
	requires java.sql;
	requires com.microsoft.sqlserver.jdbc;
}