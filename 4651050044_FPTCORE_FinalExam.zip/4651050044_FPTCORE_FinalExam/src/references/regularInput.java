/*
	Author: YangKlee - Nguyen Khanh Duong
	Date: 9 thg 1, 2025
*/ 
package references;

public interface regularInput {
	public String regex_Date = "^[0-9]{2}\\-[0-9]{2}\\-[0-9]{4}$";
	public String regex_phone = "^[0][0-9]{9}$";
	public String regex_diem = "^[0-9]+(\\.[0-9])?$";
}
